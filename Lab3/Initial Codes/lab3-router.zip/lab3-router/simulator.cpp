/* DO NOT MODIFY THIS FILE */
extern int main_loop(int argc, char** argv);

int main(int argc, char** argv) {
    return main_loop(argc, argv);
}