extern int SimulatorMainLoop(int argc, char** argv);

int main(int argc, char** argv) { SimulatorMainLoop(argc, argv); }