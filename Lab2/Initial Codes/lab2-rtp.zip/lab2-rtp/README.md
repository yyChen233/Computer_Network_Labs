详细信息请参见 [lab2 documents](https://github.com/N2Sys-EDU/Lab2-Documentation)
